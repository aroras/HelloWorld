//
//  ViewController.h
//  HelloWorld
//
//  Created by Surabhi arora on 1/31/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
  IBOutlet UILabel *label;
}
@property (nonatomic, retain) IBOutlet UILabel *label;
@end
